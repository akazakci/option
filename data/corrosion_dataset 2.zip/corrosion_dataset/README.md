-- Small dataset of corrosion images (20 train / 10 test examples) for the Edge Computing & Computer Vision course at MINES ParisTech. 

Images have been for the downloaded from the net using simple_image_download (https://github.com/RiddlerQ/simple_image_download).
